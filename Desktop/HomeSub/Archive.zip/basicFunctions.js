function linkTo(s) {
  window.open(s,'_self');
}
